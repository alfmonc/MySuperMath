
Thank you for downloading this icon set

Author: Piero Bello
Icon set: "Heroes & Villains"
Icons: 48
Description: This is an icon collection based on Marvel comics and DC comics characters.
Email: silent009@hotmail.com
Country: Venezuela
License: Free for non-commercial use. The images or characters depicted in these icons are � by Marvel Comics and DC Comics.
Enjoy it! ^_^


Please feel free to contact me if you want to share other icons sets.